# SSF Morocco RP — ELITE

Site vitrine statique, responsive, conçu pour être publié gratuitement sur GitHub Pages. Ce dossier est indépendant du site précédent.

## Fonctionnalités
- Design sombre cinématique, accent rouge/vert et détails dorés.
- Interface français / anglais / arabe avec direction RTL pour l'arabe.
- Formulaire de candidature en 3 étapes, validation, récapitulatif et sauvegarde locale.
- QCM avec navigation, réponses, score sur 100 et correction détaillée.
- Dashboard de démonstration avec aperçu des questions, candidatures locales et export JSON.
- Sections présentation, actualités, règles, FAQ, favicon, SEO et Open Graph.
- Responsive mobile/tablette/desktop et respect de `prefers-reduced-motion`.

## Démarrage local
Ouvrez `index.html` dans un navigateur. Aucune compilation ni dépendance JavaScript externe n'est nécessaire. La police Google Fonts se charge depuis Internet; des polices de secours sont prévues.

## Personnalisation
- `style.css` : couleurs, tailles, disposition et responsive.
- `index.html` : textes, sections, règles, actualités et liens.
- `data.js` : questions/réponses du QCM. `correct` est l'index de la réponse correcte à partir de zéro.
- `script.js` : logique du formulaire, du QCM, des langues et du tableau de bord.
- Dans `data.js`, remplacez `DISCORD_URL: ''` par un lien d'invitation valide pour activer le bouton Discord. Aucun lien n'est inventé.
- Modifiez `PASS_THRESHOLD: 70` pour ajuster le seuil de réussite d'entraînement.

## Publication gratuite sur GitHub Pages
1. Créez un **nouveau repository** GitHub, par exemple `ssf-morocco-rp-elite`. Ne choisissez pas le repository du site existant.
2. Décompressez le ZIP sur votre ordinateur.
3. Dans le nouveau repository, choisissez **Add file → Upload files**, puis téléversez le contenu du dossier `ssf-elite` (index.html, style.css, script.js, data.js, README.md et assets/).
4. Faites **Commit changes**.
5. Ouvrez **Settings → Pages**. Dans Build and deployment, choisissez **Deploy from a branch**, branche `main`, dossier `/ (root)`, puis **Save**.
6. Attendez la fin du déploiement GitHub Pages et ouvrez l'URL affichée dans Settings → Pages.

## Limites importantes
- GitHub Pages héberge des fichiers statiques : il ne fournit pas de backend ni de base de données.
- Les candidatures sont stockées dans `localStorage` du navigateur utilisé et ne sont pas envoyées à l'administration. Le dashboard n'est pas sécurisé et n'est pas une vraie interface d'administration.
- Le QCM est un entraînement côté client : le score n'est ni officiel ni protégé contre la triche.
- Pour des candidatures partagées entre appareils, un vrai panneau d'administration ou des comptes sécurisés, connectez un backend/API avec authentification et règles de sécurité.
- SSF Morocco RP est présenté comme un projet Roleplay virtuel indépendant, sans affiliation gouvernementale.

## Vérifications
Les fichiers sont statiques et leurs liens internes sont relatifs. Après modification, vérifiez les trois langues, les étapes du formulaire, les cinq questions du QCM et la version mobile dans votre navigateur. Ce projet n'a pas été testé dans tous les navigateurs ni déployé sur votre compte GitHub.
